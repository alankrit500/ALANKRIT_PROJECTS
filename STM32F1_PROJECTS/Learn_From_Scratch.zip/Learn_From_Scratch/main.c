#include "stm32f10x.h"
#include "stdio.h"
#include "stdlib.h"
#include "stdarg.h"
#include "string.h"
#include "ALAN_GPIO.h"
#include "print.h"


void ALAN_GPIO_Init(void);
uint8_t value;

int main()
{
  UART_Init();
	ALAN_GPIO_Init();
	GPIO_INT_Confg(GPIOB,GPIO_PIN_7,BOTH_EDGES);   // Interrupt Configuration
	Enable_EXTI(GPIO_PIN_7,EXTI9_5_IRQn);             // NVIC Enable 
//	RCC->APB2ENR |=(1<<4);    //GPIOC : Clock_Enable
//  GPIOC->CRH |=(1<<21);     //GPIOC_PIN_13 : Output_Mode : Freq_2MHz
//	GPIOC->CRH &=(~(1<<20) | ~(1<<22) | ~(1<<23));
	value=0;
	while(1)
	{
//	GPIOC->BSRR |=(1<<13);   //GPIO_Pin_Set
//	for(int i=0;i<2000000;i++)
//	{}
//	GPIOC->BSRR |=(1<<29);  //GPIO_Pin_Reset
//	for(int i=0;i<2000000;i++)
//	{}
//		 ALAN_GPIO_TogglePin(GPIOC,GPIO_PIN_13);
//		for(int i=0;i<2000000;i++)
//	  {}
		 ALAN_GPIO_WritePin(GPIOC,GPIO_PIN_13,1);
		for(int i=0;i<2000000;i++)
	  {}
		ALAN_GPIO_WritePin(GPIOC,GPIO_PIN_13,0);
		for(int i=0;i<2000000;i++)
	  {}
//		  value=ALAN_GPIO_ReadPin(GPIOA,GPIO_PIN_0);
//		  printmsg("value:%d\n",value);
//		  for(int i=0;i<5000000;i++)
//      {}

}
	return 0;
}

void ALAN_GPIO_Init(void)
{
	GPIO_type_init ALAN_GPIO_Init;
	
//	GPIO_PORTC_CLOCK_EN();
	ALAN_GPIO_Init.Port=GPIOC;              // PORT C
	ALAN_GPIO_Init.Pin_Number=GPIO_PIN_13;
	ALAN_GPIO_Init.Mode=OUTPUT;
	ALAN_GPIO_Init.Mode_Type=OUTPUT_GEN_PURPOSE;
	ALAN_GPIO_Init.Speed=SPEED_10MHz;
//	GPIO_Configuration(GPIOC, GPIO_PIN_13,1, OUTPUT_GEN_PURPOSE,SPEED_10MHz);
   GPIO_Configuration(ALAN_GPIO_Init.Port, ALAN_GPIO_Init.Pin_Number,ALAN_GPIO_Init.Mode, ALAN_GPIO_Init.Mode_Type,ALAN_GPIO_Init.Speed);
		
	ALAN_GPIO_Init.Port=GPIOB;              // PORT B
	ALAN_GPIO_Init.Pin_Number=GPIO_PIN_3;
	ALAN_GPIO_Init.Mode=INPUT;
	ALAN_GPIO_Init.Mode_Type=INPUT_PU_PD;
	ALAN_GPIO_Init.Speed=NO_SPEED;
	GPIO_Configuration(ALAN_GPIO_Init.Port, ALAN_GPIO_Init.Pin_Number,ALAN_GPIO_Init.Mode, ALAN_GPIO_Init.Mode_Type,ALAN_GPIO_Init.Speed);
	
}

void EXTI9_5_IRQHandler(void) 
{
		Clear_EXTI(GPIO_PIN_7);   // Clear EXTI_PR bit value.
	  value=200;
//	ALAN_GPIO_TogglePin(GPIOC,GPIO_PIN_13);	
	//for(int i=0;i<250000;i++);
}