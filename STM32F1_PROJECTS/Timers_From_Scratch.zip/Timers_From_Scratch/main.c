#include "stm32f10x.h"
#include "stdlib.h"
#include "ALAN_GPIO.h"
#include "print.h"

volatile uint16_t value=100;
static void GPIO_Initialize(void)
{
	GPIO_type_init GPIO_Config;
	GPIO_Config.Port=GPIOC;
	GPIO_Config.Pin_Number=GPIO_PIN_13;
	GPIO_Config.Mode=OUTPUT;
	GPIO_Config.Mode_Type=OUTPUT_GEN_PURPOSE;
	GPIO_Config.Speed=SPEED_2MHz;
	GPIO_Configuration(GPIO_Config.Port, GPIO_Config.Pin_Number,GPIO_Config.Mode, GPIO_Config.Mode_Type,GPIO_Config.Speed);
}
int main()
{
	GPIO_Initialize();
	UART_Init();                                   // A9 : UART_Transmit
//	GPIO_PORTA_CLOCK_EN();                         // A8 : RCC_Register_Clock_EN
//	GPIOA->CRH &=~GPIO_CRL_MODE1_0;
//	GPIOA->CRH |= GPIO_CRL_MODE1_1;
//	GPIOA->CRH &=~GPIO_CRL_CNF1_0; 
//	GPIOA->CRH |= GPIO_CRL_CNF1_1;	
//	RCC->APB1ENR |=(RCC_APB1ENR_TIM2EN);           // TIM2 RCC_REGISTERS_CLOCK_EN               (IMP.)
                 
//  TIM2->CR1 &=~TIM_CR1_DIR;                      // DIR : UPCOUNTER '0' ; DOWNCOUNTER '1' 
//	TIM2->CR1 &= ~TIM_CR1_ARPE;
//	TIM2->CCMR1 &=~(TIM_CCMR1_CC2S_0 | TIM_CCMR1_CC2S_1); 
//	TIM2->CCMR1 |= TIM_CCMR1_OC1PE;
//	TIM2->CCMR1 &= ~TIM_CCMR1_OC2M_0;
//	TIM2->CCMR1 |= TIM_CCMR1_OC2M_1;
//	TIM2->CCMR1 |= TIM_CCMR1_OC2M_2;
//	TIM2->CCER &= ~TIM_CCER_CC2P;
//	TIM2->CCER |= TIM_CCER_CC2E;
//	
//  TIM2->CR1 &= ~((1<<5)|(1<<6));	               // TIM2_CR_CMS
//	TIM2->PSC=7200;                                // TIM2_PSC
//	TIM2->ARR=65535;                               // TIM2_ARR
//	TIM2->CCR2=32000;
//  TIM2->EGR |= TIM_EGR_UG;
//  TIM2->CR1 |= TIM_CR1_CEN;	                     // TIM1_CR1_CEN                              (IMP.)
	GPIO_PORTB_CLOCK_EN();                         // A8 : RCC_Register_Clock_EN
	GPIOB->CRH |= GPIO_CRH_MODE9_0;
	GPIOB->CRH |= GPIO_CRH_MODE9_1;
	GPIOB->CRH &=~GPIO_CRH_CNF9_0; 
	GPIOB->CRH |= GPIO_CRH_CNF9_1;	
	RCC->APB1ENR |=(RCC_APB1ENR_TIM4EN);           // TIM4 RCC_REGISTERS_CLOCK_EN               (IMP.)
	TIM4->CCER |= TIM_CCER_CC4E;
  TIM4->CR1 |= ~TIM_CR1_ARPE;
 	TIM4->CCMR2 |= (TIM_CCMR2_OC4PE | TIM_CCMR2_OC4M_1 | TIM_CCMR2_OC4M_2);
   
  TIM4->CR1 &=~TIM_CR1_DIR;                      // DIR : UPCOUNTER '0' ; DOWNCOUNTER '1' 	 
  TIM4->CR1 &= ~((1<<5)|(1<<6));	               // TIM4_CR_CMS
	TIM4->PSC=72;                                // TIM4_PSC
	TIM4->ARR=1000;                               // TIM4_ARR
	TIM4->CCR4=250;
	TIM4->EGR |= TIM_EGR_UG;                      // (IMP.)               
  TIM4->CR1 |= TIM_CR1_CEN;	                     // TIM4_CR1_CEN    
	value=0;
	while(1)
	{
		ALAN_GPIO_TogglePin(GPIOC,GPIO_PIN_13);
	  value=ALAN_GPIO_ReadPin(GPIOB,GPIO_PIN_9);
		printmsg("CNT:%d  ; ",TIM4->CNT);
		printmsg("value:%d\n",value);		
		for(int i=0;i<1000000;i++);
//		value++;
	}
	return 0;
}