#include "stm32f10x.h"
#include "stdlib.h"
#include "stdarg.h"
#include "stdint.h"
#include "string.h"

#define DEBUG_UART USART1
#define DELAY for(int j=0;j<500000;j++){}

static void printmsg(char *msg,...)
{
char Buffer[60];
#ifdef DEBUG_UART
	va_list args;                            // Argument ??
	va_start(args,msg);                      // ??
	vsprintf(Buffer,msg,args);               // ??
	for(int i=0;i<strlen(Buffer);i++)
	{
	USART1->DR=Buffer[i];
  	while(!(USART1->SR & USART_SR_TXE));   // Command works. Why?
//	while((USART_SR_TXE != 1));            // Command does not work. Why?
	}
#endif	
}
	
int main()
{
	//Alternate Function on Pin PB6 is not working. Need to find it out.
//	AFIO->MAPR|=(1<<2);                                     //Alternate Function Remapping Active. i.e. Tx=> PB6
//	RCC->APB2ENR|=((1<<3) | (1<<0) | (1<<14));              //Clock of AF , GPIOB , USART1 Active
//	GPIOB->CRL|=((1<<25) | (1<<27));                        //GPIO_PORTB_ENABLE
//      GPIOB->CRL&=~((1<<24) & (1<<26));	
//	USART1->BRR=0x1D4C;
//	USART1->CR1 |=((1<<13) | (1<<3));                       // USART1 Enable : TE-Bit & UE-Bit
//	USART1->CR1 &=~(1<<12);                                 // USART1 Word-Length : 8-bit
		                                    
	RCC->APB2ENR|=((1<<2) | (1<<0) | (1<<14));              //Clock of AF , GPIOB , USART1 Active
	GPIOA->CRH|=((1<<5) | (1<<7));                          //GPIO_PORTB_ENABLE :: GPIO_OUTPUT
        GPIOA->CRH&=~((1<<4) & (1<<6));	
	USART1->BRR=0x271;
	USART1->CR1 |=((1<<13) | (1<<3));                       // USART1 Enable : TE-Bit & UE-Bit
	USART1->CR1 &=~(1<<12);                                 // Word Length
	while(1)
	{
		printmsg("ALANKRIT\n");
		DELAY;
	}
	return 0;
}

