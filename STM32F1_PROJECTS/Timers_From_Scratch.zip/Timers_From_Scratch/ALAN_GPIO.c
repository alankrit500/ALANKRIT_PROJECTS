#include "stm32f10x.h"
#include <stdlib.h>
#include "ALAN_GPIO.h"

uint16_t PINPOS[16]={0x00,  //GPIO_CRL //Pin 0
	0x04,                      //Pin 1
	0x08,                      //Pin 2
	0x0C,                      //Pin 3
	0x10,                      //Pin 4
  0x14,                      //Pin 5
	0x18,                      //Pin 6
	0x1C,                      //Pin 7 
	0x00,  //GPIO_CRH          //Pin 8
	0x04,                      //Pin 9
	0x08,                      //Pin 10
	0x0C,                      //Pin 11
  0x10,                      //Pin 12
	0x14,                      //Pin 13
	0x18,                      //Pin 14
	0x1C                       //Pin 15
};

uint8_t PORTNUM[8]={0x00, //GPIOA
0x01, //GPIOB
0x02, //GPIOC
0x03, //GPIOD
0x04, //GPIOE
0x05, //GPIOF
0x06  //GPIOG
}; 

void GPIO_INT_Confg(GPIO_TypeDef *PORT, uint8_t pin_number,uint8_t Edge)
{
//	uint8_t Port_Set;

//	RCC->APB2ENR |=RCC_APB2ENR_AFIOEN ;    // Enabling Alternate Function Clock
//	 
//	if(PORT == GPIOA)
// {
//	GPIO_PORTA_CLOCK_EN();                 // Enabling Port Clock              
//  Port_Set=PORTNUM[0];
// }	
//  else if(PORT == GPIOB)
// {
//	GPIO_PORTB_CLOCK_EN(); 
//	Port_Set=PORTNUM[1];
// }
// else if(PORT == GPIOC)
// {
//	GPIO_PORTC_CLOCK_EN(); 
//  Port_Set=PORTNUM[2];
// }
// else if(PORT == GPIOD)
// {
//	GPIO_PORTD_CLOCK_EN(); 
//	Port_Set=PORTNUM[3];
// }
//   else if(PORT == GPIOE)
// {
//	GPIO_PORTE_CLOCK_EN(); 
//	Port_Set=PORTNUM[4];
// }
// else if(PORT == GPIOF)
// {
//	GPIO_PORTF_CLOCK_EN(); 
//  Port_Set=PORTNUM[5];
// }
// else if(PORT == GPIOG)
// {
//	GPIO_PORTG_CLOCK_EN(); 
//	Port_Set=PORTNUM[6];
// }
//	  if(pin_number<4)
//	 {
//		 AFIO->EXTICR[0]|=Port_Set<<(4*pin_number);
//	 }
//	 else if(pin_number>3 && pin_number<8)
//	 {
//		 AFIO->EXTICR[1]|=Port_Set<<(4*(pin_number-4));			 
//	 }
//	 else if(pin_number>7 && pin_number<12)
//	 {
//		 AFIO->EXTICR[2]|=Port_Set<<(4*(pin_number-8));			 
//	 }
//	 else if(pin_number>11 && pin_number<16)
//	 {
//		 AFIO->EXTICR[3]|=Port_Set<<(4*(pin_number-12));		 
//	 }
  	RCC->APB2ENR |=RCC_APB2ENR_AFIOEN ;    // Enabling Alternate Function Clock
		if(PORT==GPIOA)
	{
		switch(pin_number)
		{
			case 0:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI0_PA;	
			break;
			case 1:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI1_PA;	
			break;
			case 2:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI2_PA;	
			break;
			case 3:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI3_PA;	
			break;
			case 4:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI4_PA;	
			break;
			case 5:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI5_PA;	
			break;
			case 6:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI6_PA;	
			break;
			case 7:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI7_PA;	
			break;
			case 8:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI8_PA;	
			break;
			case 9:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI9_PA;	
			break;
			case 10:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI10_PA;	
			break;
			case 11:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI11_PA;	
			break;
			case 12:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI12_PA;	
			break;
			case 13:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI13_PA;	
			break;
			case 14:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI14_PA;	
			break;
			case 15:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI15_PA;	
			break;			
		}
	}
		else if(PORT==GPIOB)
	{
		switch(pin_number)
		{
			case 0:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI0_PB;	
			break;
			case 1:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI1_PB;	
			break;
			case 2:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI2_PB;	
			break;
			case 3:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI3_PB;	
			break;
			case 4:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI4_PB;	
			break;
			case 5:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI5_PB;	
			break;
			case 6:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI6_PB;	
			break;
			case 7:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI7_PB;	
			break;
			case 8:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI8_PB;	
			break;
			case 9:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI9_PB;	
			break;
			case 10:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI10_PB;	
			break;
			case 11:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI11_PB;	
			break;
			case 12:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI12_PB;	
			break;
			case 13:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI13_PB;	
			break;
			case 14:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI14_PB;	
			break;
			case 15:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI15_PB;	
			break;			
		}
	}
		else if(PORT==GPIOC)
	{
		switch(pin_number)
		{
			case 0:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI0_PC;	
			break;
			case 1:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI1_PC;	
			break;
			case 2:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI2_PC;	
			break;
			case 3:
			AFIO->EXTICR[0]|=AFIO_EXTICR1_EXTI3_PC;	
			break;
			case 4:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI4_PC;	
			break;
			case 5:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI5_PC;	
			break;
			case 6:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI6_PC;	
			break;
			case 7:
			AFIO->EXTICR[1]|=AFIO_EXTICR2_EXTI7_PC;	
			break;
			case 8:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI8_PC;	
			break;
			case 9:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI9_PC;	
			break;
			case 10:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI10_PC;	
			break;
			case 11:
			AFIO->EXTICR[2]|=AFIO_EXTICR3_EXTI11_PC;	
			break;
			case 12:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI12_PC;	
			break;
			case 13:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI13_PC;	
			break;
			case 14:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI14_PC;	
			break;
			case 15:
			AFIO->EXTICR[0]|=AFIO_EXTICR4_EXTI15_PC;	
			break;			
		}
	}
	 	switch(Edge)
	 {
		 case RISING_EDGE:
		 EXTI->RTSR|=(1<<pin_number);
		 break;
		 case FALLING_EDGE:
		 EXTI->FTSR|=(1<<pin_number);
		 break;	
		 case BOTH_EDGES:
		 EXTI->RTSR|=(1<<pin_number);
		 EXTI->FTSR|=(1<<pin_number);
		 break;		 
	 }
 }

 void GPIO_Configuration(GPIO_TypeDef *PORT, uint32_t Pin_Number,uint32_t Mode, uint32_t Mode_Type,uint32_t Speed)
{
 if(PORT == GPIOA)
 {
	GPIO_PORTA_CLOCK_EN(); 
 }	
  else if(PORT == GPIOB)
 {
	GPIO_PORTB_CLOCK_EN(); 
 }
 else if(PORT == GPIOC)
 {
	GPIO_PORTC_CLOCK_EN(); 
 }
 else if(PORT == GPIOD)
 {
	GPIO_PORTD_CLOCK_EN(); 
 }
  
if(Pin_Number>=8)       // 2 switch cases back to back create problems , therefore every decision-making statement.
{                       // i.e. "if-statements" are written before switch case. 
if(Mode==0)             // It can also be said switch cases are written towards the end of Program 
{
	PORT->CRH &=(~(1 << MODE_POS_BIT1) && ~(1 << MODE_POS_BIT2));
}
switch(Mode_Type)
{
	case (OUTPUT_GEN_PURPOSE | INPUT_ANALOG) :   // It is same as shifting,say, (1<<10) as 1 shifted by 10 bits.
	PORT->CRH &=(~(1 << CNF_POS_BIT1) && ~(1 << CNF_POS_BIT2));
	break;	
	case (OUTPUT_OD | INPUT_FLOATING) :
	PORT->CRH &=(~(1 << CNF_POS_BIT2));
	PORT->CRH |=(1 << CNF_POS_BIT1);
	break;	
	case (OUTPUT_ALT_FUNCTION   | INPUT_PU_PD) :
	PORT->CRH &=(~(1 << CNF_POS_BIT1));
	PORT->CRH |=(1 << CNF_POS_BIT2);
	break;
	case (OUTPUT_ALT_FUNCTION_OD) :   // It is same as shifting,say, (1<<10) as 1 shifted by 10 bits.
	PORT->CRH |=((1 << CNF_POS_BIT1) && (1 << CNF_POS_BIT2));
	break;
}
switch(Speed)  //Input Mode
{	
	case (SPEED_10MHz) :
	PORT->CRH &=(~(1 << MODE_POS_BIT2));
	PORT->CRH |=(1 << MODE_POS_BIT1);
	break;	
	case (SPEED_2MHz) :
	PORT->CRH &=(~(1 << MODE_POS_BIT1));
	PORT->CRH |=(1 << MODE_POS_BIT2);
	break;
	case (SPEED_50MHz) :   // It is same as shifting,say, (1<<10) as 1 shifted by 10 bits.
	PORT->CRH |=((1 << MODE_POS_BIT1) && (1 << MODE_POS_BIT2));
	break;
}
}
else if(Pin_Number <=7)
{
if(Mode==0)
{
	PORT->CRL &=(~(1 << MODE_POS_BIT1) && ~(1 << MODE_POS_BIT2));
}
switch(Mode_Type)
{
	case (OUTPUT_GEN_PURPOSE | INPUT_ANALOG) :   // It is same as shifting,say, (1<<10) as 1 shifted by 10 bits.
	PORT->CRL &=(~(1 << CNF_POS_BIT1) && ~(1 << CNF_POS_BIT2));
	break;	
	case (OUTPUT_OD | INPUT_FLOATING) :
	PORT->CRL &=(~(1 << CNF_POS_BIT2));
	PORT->CRL |=(1 << CNF_POS_BIT1);
	break;	
	case (OUTPUT_ALT_FUNCTION   | INPUT_PU_PD) :
	PORT->CRL &=(~(1 << CNF_POS_BIT1));
	PORT->CRL |=(1 << CNF_POS_BIT2);
	break;
	case (OUTPUT_ALT_FUNCTION_OD) :   // It is same as shifting,say, (1<<10) as 1 shifted by 10 bits.
	PORT->CRL |=((1 << CNF_POS_BIT1) && (1 << CNF_POS_BIT2));
	break;
}
switch(Speed)  //
{	
	case (SPEED_10MHz) :
	PORT->CRL &=(~(1 << MODE_POS_BIT2));
	PORT->CRL |=(1 << MODE_POS_BIT1);
	break;	
	case (SPEED_2MHz) :
	PORT->CRL &=(~(1 << MODE_POS_BIT1));
	PORT->CRL |=(1 << MODE_POS_BIT2);
	break;
	case (SPEED_50MHz) :   // It is same as shifting,say, (1<<10) as 1 shifted by 10 bits.
	PORT->CRL |=((1 << MODE_POS_BIT1) && (1 << MODE_POS_BIT2));
	break;
}
}	
}

void ALAN_GPIO_TogglePin(GPIO_TypeDef *PORT,uint8_t Pin)
{ 
	//	  uint8_t Toggle;                                         // Method 1: Of GPIO Toggle
//	  if(Toggle==1)
//		PORT->BSRR |=(1<<Pin);       //GPIO_Pin_Set
//	  else
//		PORT->BSRR |=(1<<(Pin+16));  //GPIO_Pin_Reset
//		Toggle=~Toggle;
	GPIOC->ODR ^=(1<<Pin);           //GPIO_Pin_Toggle            // Method 2: Of GPIO Toggle
}
void ALAN_GPIO_WritePin(GPIO_TypeDef *PORT,uint8_t Pin,uint8_t Pin_State)
{ 
	  if(Pin_State==1)
		PORT->BSRR |=(1<<Pin);   //GPIO_Pin_Set
	  else
		PORT->BSRR |=(1<<(Pin+16));  //GPIO_Pin_Reset
}
int ALAN_GPIO_ReadPin(GPIO_TypeDef *PORT,uint8_t Pin)
{
	uint8_t pin_flag;
	pin_flag= (PORT->IDR << Pin);
	return pin_flag;
}

void Enable_EXTI(uint32_t pin_number,IRQn_Type IRQNumber)
{    
	// Enable Interrupt in EXTI
 		 EXTI->IMR|=(1<<pin_number);
  // Enable Interrupt in NVIC
     NVIC_EnableIRQ(IRQNumber);	
}
void Clear_EXTI(uint32_t pin_number)
{
	// Clear Interrupt in EXTI
 		 EXTI->PR|=(1<<pin_number);	
}