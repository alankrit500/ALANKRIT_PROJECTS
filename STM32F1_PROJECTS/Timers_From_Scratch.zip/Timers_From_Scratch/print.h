#ifndef print
#define print
#include "stm32f10x.h"

#define DEBUG_UART USART1
#define DELAY for(int j=0;j<500000;j++){}
	
void UART_Init(void);
volatile void printmsg(char *msg,...);
#endif