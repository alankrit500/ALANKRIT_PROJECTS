#include "stm32f10x.h"
#include "stdlib.h"
#include "stdarg.h"
#include "stdint.h"
#include "string.h"
#include "print.h"

void UART_Init(void)    //Call this Function in main()
{
	RCC->APB2ENR|=((1<<2) | (1<<0) | (1<<14));              //Clock of AF , GPIOB , USART1 Active
	GPIOA->CRH|=((1<<5) | (1<<7));                          //GPIO_PORTA_ENABLE
  GPIOA->CRH&=~((1<<4) & (1<<6));	
	USART1->BRR=0x271;
	USART1->CR1 |=((1<<13) | (1<<3));                       // USART1 Enable : TE-Bit & UE-Bit
	USART1->CR1 &=~(1<<12);                                 // Word Length
}
volatile void printmsg(char *msg,...)
{
char Buffer[60];
#ifdef DEBUG_UART
	va_list args;                            // Argument ??
	va_start(args,msg);                      // ??
	vsprintf(Buffer,msg,args);               // ??
	for(int i=0;i<strlen(Buffer);i++)
	{
	USART1->DR=Buffer[i];
  	while(!(USART1->SR & USART_SR_TXE));   // Command works. Why?
//	while((USART_SR_TXE != 1));            // Command does not work. Why?
	}
#endif	
}