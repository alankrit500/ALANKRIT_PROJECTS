#ifndef ALAN_GPIO
#define ALAN_GPIO
#include "stm32f10x.h"

#define GPIO_PIN_0 0
#define GPIO_PIN_1 1
#define GPIO_PIN_2 2
#define GPIO_PIN_3 3

#define GPIO_PIN_4 4
#define GPIO_PIN_5 5
#define GPIO_PIN_6 6
#define GPIO_PIN_7 7

#define GPIO_PIN_8 8
#define GPIO_PIN_9 9
#define GPIO_PIN_10 10
#define GPIO_PIN_11 11

#define GPIO_PIN_12 12
#define GPIO_PIN_13 13
#define GPIO_PIN_14 14
#define GPIO_PIN_15 15

#define INPUT 0
#define OUTPUT 1

#define RISING_EDGE 0
#define FALLING_EDGE 1
#define BOTH_EDGES 2

// GPIO INPUT MODE TYPES
#define INPUT_ANALOG             (0x00)
#define INPUT_FLOATING           (0x01)
#define INPUT_PU_PD              (0x10)   

// GPIO OUTPUT MODE TYPES
#define OUTPUT_GEN_PURPOSE      (0x00) //Output General Purpose : Output Push-Pull
#define OUTPUT_OD               (0x01) //Output Open Drain
#define OUTPUT_ALT_FUNCTION     (0x10)  //ALT_FUNCTION : Output Push-Pull
#define OUTPUT_ALT_FUNCTION_OD  (0x11)  //ALT_FUNCTION_OD

// PIN SPEED / SLEW RATE
#define NO_SPEED                (0x00)
#define SPEED_10MHz             (0x01)    // Output Mode:10 MHz
#define SPEED_2MHz              (0x10)    // Output Mode:2 MHz
#define SPEED_50MHz             (0x11)   // Output Mode:50 MHz

//GPIO CLOCK
#define GPIO_AF_EN() (RCC->APB2ENR |=(1<<0))                    // CLOCK ENABLING
#define GPIO_PORTA_CLOCK_EN() (RCC->APB2ENR |=(1<<2))
#define GPIO_PORTB_CLOCK_EN() (RCC->APB2ENR |=(1<<3))
#define GPIO_PORTC_CLOCK_EN() (RCC->APB2ENR |=(1<<4))
#define GPIO_PORTD_CLOCK_EN() (RCC->APB2ENR |=(1<<5))
#define GPIO_PORTE_CLOCK_EN() (RCC->APB2ENR |=(1<<6))
#define GPIO_PORTF_CLOCK_EN() (RCC->APB2ENR |=(1<<7))
#define GPIO_PORTG_CLOCK_EN() (RCC->APB2ENR |=(1<<8))

//Accessing CNF bits and MODE bits                 // Here, 0,1,2,3 are used to shift from Base Address of the Pin.
#define MODE_POS_BIT1 PINPOS[Pin_Number]           // This macro is accessing the bits directly.
#define MODE_POS_BIT2 (PINPOS[Pin_Number] + 1)     // i.e. Bit that require to be configured, it can be accessed directly.
#define CNF_POS_BIT1 (PINPOS[Pin_Number] + 2)
#define CNF_POS_BIT2 (PINPOS[Pin_Number] + 3)


typedef struct                                     // This structure when initialized, it will configure GPIO_PIN_MODE; content of this structure
{                                                  // initialize in main.
	GPIO_TypeDef *Port;
	uint32_t Pin_Number;                       // GPIO_PIN_NUMBER
	uint32_t Mode;                             // GPIO_MODE_DEF
	uint32_t Mode_Type;
	uint32_t Pull;
	uint32_t Speed;
	uint32_t alt_func;
}GPIO_type_init;

void GPIO_Configuration(GPIO_TypeDef *PORT, uint32_t Pin_Number,uint32_t Mode, uint32_t Mode_Type,uint32_t Speed);
void ALAN_GPIO_TogglePin(GPIO_TypeDef *PORT,uint8_t Pin);
void ALAN_GPIO_WritePin(GPIO_TypeDef *PORT,uint8_t Pin,uint8_t Pin_State);
int ALAN_GPIO_ReadPin(GPIO_TypeDef *PORT,uint8_t Pin);

//*********************************************************INTERRUPT_FUNCTIONS****************************************************************
void GPIO_INT_Confg(GPIO_TypeDef *PORT, uint8_t pin_number,uint8_t Edge);
void Enable_EXTI(uint32_t pin_number,IRQn_Type IRQNumber);
void Disable_EXTI(uint32_t pin_number,IRQn_Type IRQNumber);
void Clear_EXTI(uint32_t pin_number);
#endif