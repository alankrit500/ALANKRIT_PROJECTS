/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd_hd44780_lib.h"
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ELEMS(p) (sizeof(p)/sizeof(p[0]))
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

/* USER CODE BEGIN PV */
CAN_TxHeaderTypeDef   TxHeader;
CAN_RxHeaderTypeDef   RxHeader;
uint8_t               TxData[8];
uint8_t               RxData[8];
uint32_t              TxMailbox;

volatile unsigned long int Licznikms;
volatile uint16_t Timer_sys[6];
volatile unsigned long int uwTickms;
volatile unsigned int Tickms;
//volatile unsigned long int Ticks;
volatile unsigned long int g_COUNT_SEC;

uint32_t g_Count1_recv, g_Count2_recv, g_Count_send;
uint8_t g_Text_on_LCD[10] = {"0\0"};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN_Init(void);
/* USER CODE BEGIN PFP */
static HAL_StatusTypeDef CAN_Polling(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint32_t CAN1_ERR;
	uint32_t CAN1_STATE;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN_Init();
  /* USER CODE BEGIN 2 */

  LCD_Initialize();
  LCD_WriteCommand(HD44780_CLEAR);
  LCD_WriteText((uint8_t*)"TEST CAN1 LOOPBACK\0");
  HAL_Delay(2000);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  if (Timer_sys[0] == 0)
	  	  {
			Timer_sys[0] = 1000;
			if (CAN_Polling() ==  HAL_OK)
			{ /* OK */

			  /* Toggle LED1 */
				HAL_GPIO_TogglePin(GPIOB, LD4_Pin);
			}
			else
			{ /* NOK */

			  /* Toggle LED2 */
				HAL_GPIO_TogglePin(GPIOB, LD5_Pin);
			}

	  	  }

	  if (Timer_sys[1] == 0)
		{
		  Timer_sys[1] = 100;
		  HAL_GPIO_TogglePin(LD6_GPIO_Port, LD6_Pin);

		  CAN1_ERR = HAL_CAN_GetError(&hcan);
		  CAN1_STATE = hcan.Instance->MSR;

		  LCD_WriteCommand(HD44780_CLEAR);
		  //LCD_WriteText((uint8_t*)"CAN on STM32F103\0");
		  //sprintf((char *)licznikTekst,"%08lX",CAN1_ERR);
		  //LCD_WriteTextXY(licznikTekst,0,0);
		  //sprintf((char *)licznikTekst,"%8lX",CAN1_STATE);
		  sprintf((char *)g_Text_on_LCD,"%lu",g_Count2_recv);
		  LCD_WriteTextXY(g_Text_on_LCD,8,0);
		  sprintf((char *)g_Text_on_LCD,"%lu",g_Count1_recv);
		  LCD_WriteTextXY(g_Text_on_LCD,0,1);
		  sprintf((char *)g_Text_on_LCD,"%lu",g_Count_send);
		  LCD_WriteTextXY(g_Text_on_LCD,8,1);

		  if (CAN1_ERR != 0)
		  {
			  HAL_Delay(500);
			  CAN1_ERR = hcan.Instance->ESR;

			  CAN1_STATE = hcan.Instance->MSR;
			  sprintf((char *)g_Text_on_LCD,"%08lX",CAN1_ERR);
			  LCD_WriteTextXY(g_Text_on_LCD,0,0);
			  sprintf((char *)g_Text_on_LCD,"%8lX",CAN1_STATE);
			  LCD_WriteTextXY(g_Text_on_LCD,8,0);
			  HAL_Delay(200);

			  HAL_CAN_Stop(&hcan);
			  CAN1_STATE = HAL_CAN_GetState(&hcan);
			  CAN1_STATE = hcan.Instance->MSR;
			  sprintf((char *)g_Text_on_LCD,"%08lX",CAN1_ERR);
			  LCD_WriteTextXY(g_Text_on_LCD,0,0);
			  sprintf((char *)g_Text_on_LCD,"%8lX",CAN1_STATE);
			  LCD_WriteTextXY(g_Text_on_LCD,8,0);
			  HAL_Delay(200);
			  HAL_CAN_ResetError(&hcan);

			  CAN1_ERR = hcan.Instance->ESR;
			  CAN1_STATE = hcan.Instance->MSR;
			  sprintf((char *)g_Text_on_LCD,"%08lX",CAN1_ERR);
			  LCD_WriteTextXY(g_Text_on_LCD,0,0);
			  sprintf((char *)g_Text_on_LCD,"%8lX",CAN1_STATE);
			  LCD_WriteTextXY(g_Text_on_LCD,8,0);
			  HAL_Delay(200);
			  HAL_CAN_Start(&hcan);

			  CAN1_ERR = hcan.Instance->ESR;
			  CAN1_STATE = hcan.Instance->MSR;
			  sprintf((char *)g_Text_on_LCD,"%08lX",CAN1_ERR);
			  LCD_WriteTextXY(g_Text_on_LCD,0,0);
			  sprintf((char *)g_Text_on_LCD,"%8lX",CAN1_STATE);
			  LCD_WriteTextXY(g_Text_on_LCD,8,0);
			  HAL_Delay(200);
		  }


		}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */
	CAN_FilterTypeDef  sFilterConfig;
  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN1;
  hcan.Init.Prescaler = 2;
  hcan.Init.Mode = CAN_MODE_LOOPBACK;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_11TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_6TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = ENABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */
  /* Configure the CAN Filter */
  sFilterConfig.FilterBank = 0;
  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
  sFilterConfig.FilterIdHigh = 0x0000;
  sFilterConfig.FilterIdLow = 0x0000;
  sFilterConfig.FilterMaskIdHigh = 0x0000;
  sFilterConfig.FilterMaskIdLow = 0x0000;
  sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
  sFilterConfig.FilterActivation = ENABLE;
  sFilterConfig.SlaveStartFilterBank = 14;

  if (HAL_CAN_ConfigFilter(&hcan, &sFilterConfig) != HAL_OK)
  {
	/* Filter configuration Error */
	Error_Handler();
  }

  /* Start the CAN peripheral */
  if (HAL_CAN_Start(&hcan) != HAL_OK)
  {
	/* Start Error */
	Error_Handler();
  }

  /* Activate CAN RX notification */
  if (HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
  {
	/* Notification Error */
	Error_Handler();
  }

  /* Configure Transmission process */
  TxHeader.StdId = 0x123;
  TxHeader.ExtId = 0x0222;
  TxHeader.RTR = CAN_RTR_DATA;
  TxHeader.IDE = CAN_ID_EXT;
  TxHeader.DLC = 8;
  TxHeader.TransmitGlobalTime = DISABLE;
  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD3_Pin|LD4_Pin|LD5_Pin|LD6_Pin 
                          |LD7_Pin|LD8_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LD3_Pin LD4_Pin LD5_Pin LD6_Pin 
                           LD7_Pin LD8_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD4_Pin|LD5_Pin|LD6_Pin 
                          |LD7_Pin|LD8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
/**
  * @brief  Rx Fifo 0 message pending callback in non blocking mode
  * @param  CanHandle: pointer to a CAN_HandleTypeDef structure that contains
  *         the configuration information for the specified CAN.
  * @retval None
  */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *CanHandle)
{
  /* Get RX message */
  if (HAL_CAN_GetRxMessage(CanHandle, CAN_RX_FIFO0, &RxHeader, RxData) != HAL_OK)
  {
    /* Reception Error */
    //Error_Handler();

  }

  if ((RxHeader.ExtId == 0x222) && (RxHeader.IDE == CAN_ID_EXT) && (RxHeader.DLC == 8))
  {

	  g_Count1_recv = RxData[3];
	  g_Count1_recv = (g_Count1_recv << 8) | RxData[2];
	  g_Count1_recv = (g_Count1_recv << 8) | RxData[1];
	  g_Count1_recv = (g_Count1_recv << 8) | RxData[0];
  }

  if ((RxHeader.ExtId == 0x222) && (RxHeader.IDE == CAN_ID_EXT) && (RxHeader.DLC == 8))
    {

  	  g_Count2_recv = RxData[3];
  	  g_Count2_recv = (g_Count2_recv << 8) | RxData[2];
  	  g_Count2_recv = (g_Count2_recv << 8) | RxData[1];
  	  g_Count2_recv = (g_Count2_recv << 8) | RxData[0];
    }
}

/*
**
  * @brief  Configures the CAN, transmit and receive by polling
  * @param  None
  * @retval PASSED if the reception is well done, FAILED in other case
  */
HAL_StatusTypeDef CAN_Polling(void)
{
	/* Set the data to be transmitted */

	TxData[0] = g_Count_send++;
	TxData[1] = g_Count_send>>8;
	TxData[2] = g_Count_send>>16;
	TxData[3] = g_Count_send>>24;

	/* Start the Transmission process */
	if (HAL_CAN_AddTxMessage(&hcan, &TxHeader, TxData, &TxMailbox) != HAL_OK)
	{
	  /* Transmission request Error */
	  return HAL_ERROR;
	}


  return HAL_OK; /* Test Passed */
}

void HAL_SYSTICK_Callback(void)
{
	uint16_t t_timer;
	uint8_t i;

	Licznikms++;                        /* increment counter necessary in Delay() */
	uwTickms++;
	Tickms++;

	if (Tickms >= 1000)
	{
		Tickms = 0;
		g_COUNT_SEC++;
	}

	// Support for System TImers
	for (i = 0; i< ELEMS(Timer_sys); i++)
	{
		t_timer = Timer_sys[i];
		if (t_timer) Timer_sys[i] = --t_timer;

	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
